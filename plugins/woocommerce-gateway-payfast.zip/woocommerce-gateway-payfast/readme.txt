=== WooCommerce PayFast Gateway ===

A payment gateway for PayFast. A PayFast merchant account, merchant key and merchant ID are required for this gateway to function.

== Important Note ==

An SSL certificate is recommended for additional safety and security for your customers.