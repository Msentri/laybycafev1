=== WooCommerce LaybyCafe Gateway ===

A payment gateway for LaybyCafe. A LaybyCafe merchant account, merchant key and merchant ID are required for this gateway to function.

== Important Note ==

An SSL certificate is recommended for additional safety and security for your customers.